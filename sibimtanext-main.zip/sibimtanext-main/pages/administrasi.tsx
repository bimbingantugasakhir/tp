import type { NextPage } from 'next'

const Administrasi: NextPage = () => {
  return (
    <div>
      Hello Administrasi
    </div>
  )
}

export default Administrasi
