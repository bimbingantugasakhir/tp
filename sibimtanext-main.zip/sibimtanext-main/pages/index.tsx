
import type { NextPage } from 'next'


const Home: NextPage = () => {
  
  return (
    <div>
      SELAMAT DATANG DI SIBIMTA
    </div>
  )
  
}

export default Home
